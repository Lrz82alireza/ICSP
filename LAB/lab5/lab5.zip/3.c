#include <stdio.h>

int main()
{
    int arr[4] = {1, 2, 3, 4};
    int arr_copy[4];
    for (int i = 0; i < 4; i++)
        arr_copy[i] = arr[i];
}